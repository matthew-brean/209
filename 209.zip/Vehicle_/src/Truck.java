
public class Truck {
	
	
	  //constructor method
	  Truck() {
	    System.out.println("Constructor method Truck.");
	  }
	  
	private int _numTires;
	public int numTires(){
		
		return this._numTires = 4;
		
	}	
	
}
