
public class Bike {
	private int _numTires;

	public int numTires(){
		return this._numTires = 2;
	}	
	
	  Bike() {
		    System.out.println("Constructor method Bike.");
		  }
	
}
